package com.example.authapp1.remote

import com.example.authapp1.model.LoginRequest
import com.example.authapp1.model.TokenResponse
import com.example.authapp1.model.UserCreate
import com.example.authapp1.model.UserOut
import okhttp3.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST

interface AuthApi {
    @POST("register")
    suspend fun register(@Body user: UserCreate): Response<UserOut>

    @POST("login")
    suspend fun login(@Body request: LoginRequest): Response<TokenResponse>

    @GET("me")
    suspend fun me(@Header("Authorization") token: String): Response<UserOut>
}