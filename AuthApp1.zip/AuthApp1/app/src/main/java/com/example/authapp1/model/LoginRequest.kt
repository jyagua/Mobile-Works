package com.example.authapp1.model

data class LoginRequest (
    val email: String,
    val password: String
)