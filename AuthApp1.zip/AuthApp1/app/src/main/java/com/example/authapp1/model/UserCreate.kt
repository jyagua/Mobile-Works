package com.example.authapp1.model

data class UserCreate(
    val email: String,
    val password: String
)
