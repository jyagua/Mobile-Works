package com.example.authapp1.model

data class TokenResponse (
    val access_token: String,
    val token_type: String
)