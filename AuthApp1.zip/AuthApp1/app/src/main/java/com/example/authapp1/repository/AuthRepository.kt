package com.example.authapp1.repository

import android.content.Context
import com.example.authapp1.model.LoginRequest
import com.example.authapp1.model.UserCreate
import com.example.authapp1.model.UserOut
import com.example.authapp1.remote.AuthApi
import com.example.authapp1.util.TokenManager

class AuthRepository(
    private val api: AuthApi,
    private val context: Context
) {
    suspend fun register(email: String, password: String): Result<UserOut>{
        val response = api.register(UserCreate(email,password))
        return if (response.isSuccessful) Result.success(response.body()!!)
        else Result.failure(Exception(response.errorBody()?.string()))
    }

    suspend fun login(email: String, password: String): Result<String>{
        val response = api.login(LoginRequest(email,password))
        return if (response.isSuccessful){
            val token = response.body()!!.acess_token
            TokenManager.saveToken(context,token)
            Result.success(token)
        }else{
            Result.failure(Exception("Usuário ou senha Inválidos"))
        }
    }

    suspend fun me(): Result<UserOut>{
        val token = TokenManager.getToken(context) ?: return Result.failure(Exception("sem token"))
        val response = api.me("Bearer $token")
        return if (response.isSuccessful) Result.success(response.body()!!)
    }

    suspend fun logout(){
        TokenManager.clearToken(context)
    }
}