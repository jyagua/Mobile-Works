package com.example.authapp1.model

data class UserOut (
    val id: Int,
    val email: String
)